# Agent guide -- Reader Workspace (eval project)

**You are inside a GAD eval.** Follow this loop exactly. Your work is being traced.

## The loop (mandatory)

1. **Pick one task** from `.planning/TASK-REGISTRY.xml` (status=planned)
2. **Mark it in-progress** in TASK-REGISTRY.xml before starting work
3. **Implement it**
4. **Mark it done** in TASK-REGISTRY.xml
5. **Update STATE.xml** -- set `next-action` to describe what comes next
6. **Commit exactly one task per commit.** Message MUST include the task id (e.g. "feat: 01-02 implement reading store"). NEVER batch multiple tasks into one commit -- each task gets its own atomic commit. This is how your discipline is scored.
7. **Repeat** from step 1

## After completing each phase (all tasks done)

**Verify the phase before moving on.** Write `.planning/VERIFICATION.md` (append each phase):

```markdown
## Phase [X]: [Name]
- Build: PASS/FAIL (run the build command)
- Tasks: [N]/[N] done
- State: current (next-action points to next phase)
```

Then commit: `git commit -m "verify: phase [X] verified"`

This is mandatory -- your skill accuracy score depends on it.

## Before you start coding

1. Read `.planning/REQUIREMENTS.xml` -- the full feature spec (51 success criteria)
2. Read `.planning/DECISIONS.xml` -- architectural decisions you should follow
3. Read `.planning/CONVENTIONS.md` -- coding patterns to adhere to
4. Read `.planning/ROADMAP.xml` -- the 12-phase implementation plan
5. Plan your first phase in `.planning/TASK-REGISTRY.xml`
6. Update `.planning/STATE.xml` with current-phase and status

## Per-task checklist (MANDATORY before next task)

- [ ] TASK-REGISTRY.xml: previous task marked `done`
- [ ] STATE.xml: `next-action` updated
- [ ] Code works (build/lint/test as applicable)
- [ ] Committed with task id in message

## After first implementation phase

Create `.planning/CONVENTIONS.md` additions documenting any NEW patterns you established
beyond what was already documented.

## Decisions during work

Capture any new architectural choices in `.planning/DECISIONS.xml`:
```xml
<decision id="impl-01">
  <title>Short title</title>
  <summary>What and why</summary>
  <impact>How this affects future work</impact>
</decision>
```

## Key architecture notes

- **React package structure:** This is a library, not an app. Export components and stores
  from a public index.ts with sub-path export (`./reader`).
- **Zustand stores:** Always use persist + immer for persisted stores. Include legacy
  key migration in the custom storage adapter.
- **UI primitives:** Build your own lightweight Button, Card, Badge, etc. Do NOT install
  shadcn/ui -- create minimal equivalents.
- **Chrome theme:** All styling flows through a single theme object mapping slot names to
  Tailwind class strings.
- **Annotations:** Three persistence layers merge (IndexedDB local, EPUB embedded, remote
  adapter). Conflict resolution is last-write-wins by timestamp.
- **EpubViewer:** Lazy-loaded. Custom sepia theme. Supports paginated and scrolled modes.

## What NOT to do

- Do NOT skip TASK-REGISTRY.xml updates -- your trace depends on them
- Do NOT batch all planning updates at the end -- update PER TASK
- Do NOT batch multiple tasks into one commit -- ONE task = ONE commit. This is scored as per_task_discipline and is 20% of your composite
- Do NOT code without planning first
- Do NOT import from shadcn/ui or Radix -- build lightweight primitives
- Do NOT copy code from any external source -- implement from the requirements spec
- Do NOT create files outside the standard artifact set without reason

## Final deliverable (MANDATORY)

Your LAST phase must produce a working build. This is non-negotiable:

1. Run `npx tsup` (or the build script) -- it must succeed with zero errors
2. Create a `demo/index.html` that imports the built package and renders the ReaderWorkspace component with sample data (2-3 hardcoded books with placeholder covers)
3. The demo must be viewable in a browser -- static HTML that loads the ESM bundle
4. Commit: `git add dist/ demo/ && git commit -m "build: production dist + demo"`

The demo is what gets showcased on the docs site. No working demo = eval incomplete.

## Architecture doc (MANDATORY)

Before your final commit, write `.planning/ARCHITECTURE.md` describing what you built:
- System overview (1 paragraph)
- Key modules and what each does (bullet list)
- Data flow (stores, persistence, component tree)
- Key decisions you made and why

This is scored. 10-20 lines is enough.

## Scoring

Your work is scored on:
1. **Requirement coverage** (40%) -- how many of the 51 success criteria are met
2. **Architecture alignment** (25%) -- do your decisions match the reference decisions
3. **State hygiene** (20%) -- per-task updates, task-id commits, STATE.xml accuracy
4. **Convention adherence** (15%) -- file naming, store patterns, import patterns
